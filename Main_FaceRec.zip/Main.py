﻿from FaceRec import FaceRec


if __name__ == "__main__":
    cam = FaceRec(
        camera_index=0,  # 0 para webcam padrão
        database_path=r"C:\Users\Loure\Downloads\foto",
        model="VGG-Face",
        detect_backend="opencv",
        interval_analyse = 2
    )

    cam.CameraView()

        